package com.exemplo.headers;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HeadersApplicationTests {

	@Test
	void contextLoads() {
	}

}
