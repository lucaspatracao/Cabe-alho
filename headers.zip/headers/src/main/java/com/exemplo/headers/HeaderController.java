package com.exemplo.headers;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HeaderController {

    @GetMapping("/get-header")
    public String getHeader(@RequestHeader("X-Custom-Header") String customHeader,
                            @RequestParam String queryParam) {
        return "Valor do X-Custom-Header: " + customHeader + " | Parâmetro da query: " + queryParam;
    }

    @GetMapping("/set-header")
    public String setHeader() {
        return "Cabeçalho customizado será adicionado na resposta!";
    }
}