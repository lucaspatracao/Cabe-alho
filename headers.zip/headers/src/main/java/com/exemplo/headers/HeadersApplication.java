package com.exemplo.headers;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HeadersApplication {
	public static void main(String[] args) {
		SpringApplication.run(HeadersApplication.class, args);
	}
}